
import json
import requests
requests.packages.urllib3.disable_warnings()

class ApicSession:
    """
    Represents a session for connecting to the APIC server.

    This class provides methods to authenticate with the APIC server and interact with its API.

    Args:
        server (dict): A dictionary containing the server properties such as 'host', 'port', 'certificate', 'user', and 'passwd'.
    
    Raises:
        ConnectionError: If there is a connection error while establishing a connection with the APIC server.
        AttributeError: If there is an issue with verifying APIC credentials.

    Attributes:
        host (str): The hostname or IP address of the APIC server.
        port (int): The port number of the APIC server.
        certificate (str): The path to the SSL/TLS certificate file for verifying the server's identity.
        user (str): The username for authentication with the APIC server.
        passwd (str): The password for authentication with the APIC server.
        base_url (str): The base URL of the APIC server, constructed using the host and port.
        auth_token (str): The authentication token obtained from the APIC server.

    Methods:
        create_auth_token(): Creates an authentication token by sending a POST request to the APIC server.

    Example:
        server_props = {
            'host': 'apic.example.com',
            'port': 443,
            'certificate': '/path/to/cert.pem',
            'user': 'admin',
            'passwd': 'password'
        }
        session = ApicSession(server_props)
        session.create_auth_token()
    """

    def __init__(self, server: dict) -> None:
        self.host = server['host']
        self.port = server['port']
        self.certificate = server['certificate']
        self.user = server['user']
        self.passwd = server['passwd']
        self.domain = server['domain']
        self.base_url = f'https://{self.host}:{self.port}'
        try:
            self.auth_token = self.create_auth_token()
        except ConnectionError as e:
            raise ConnectionError('Failed to open connection with APIC!') from e

    def create_auth_token(self):
        url = f'{self.base_url}/api/aaaLogin.json'
        payload = {
            'aaaUser': {
                'attributes': {
                    'name': f'apic:{self.domain}\\{self.user}',
                    'pwd': self.passwd 
                }
            }
        }
        headers = {'Content-Type': 'application/json'}
        try:
            response = requests.post(url, headers=headers, data=json.dumps(payload), verify=self.certificate)
            if response.status_code == 200:
                return response.json()['imdata'][0]['aaaLogin']['attributes']['token']
            else:
                raise AttributeError('Failed to verify APIC credentials!')
        except Exception as e:
            raise ConnectionError('Failed to create Auth Token on APIC!') from e
