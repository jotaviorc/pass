from mso_session import MsoSession

import json
from jsonpath_ng.ext import parser

import requests
requests.packages.urllib3.disable_warnings()

class MsoInterfaces:


    def __init__ (self, site_name: str, site_id: str, interface_type: str, session: MsoSession):
        self.session = session
        self.site_id = site_id
        self.site_name = site_name
        self.interface_type = interface_type
        self.interfaces = self.get_interfaces()
        

    def get_interfaces(self):
        url = self.session.base_url + '/mso/api/v1/aci/sites/' + self.site_id + '/nodes/interfaces?type=' + self.interface_type
        headers = {
            'Cookie': 'AuthCookie=' + self.session.auth_token,
            'Content-Type': 'application/json'
        }
        try:
            response = requests.request("GET", url, headers=headers, verify=self.session.certificate)
            if response.status_code == 200:
                return response.json()
            else:
                raise AttributeError('Try to verify MSO Site Name!')
        except Exception as e:
            raise ConnectionError('Failed to fetch Interfaces from MSO!') from e