from log import initialize_log

import csv
import os, sys

import requests
requests.packages.urllib3.disable_warnings()

from config.server_config import ServerDictProps
from apic_session import ApicSession
from apic_fabric import ApicFabric
from mso_session import MsoSession
from mso_schema import MsoSchema
from mso_interfaces import MsoInterfaces
from csv_to_dict import csv_to_dict
from jsonpath_ng.ext import parser


def create_csv_object():
    return { 
        "schema": None,
        "siteName": None,
        "templateName": None,
        "applicationProfileName": None,
        "epgName": None,
        "podName": None,
        "nodeName": None,
        "intfName": None,
        "intfType": None
    }


def append_to_csv(dictionary, file_name):
    # Extract keys from the dictionary
    keys = list(dictionary.keys())
    
    # Open the CSV file in append mode if it exists; otherwise, create it
    with open(file_name, 'a', newline='') as csv_file:
        csv_writer = csv.DictWriter(csv_file, fieldnames=keys)
        
        # If the file is empty, write the header
        if csv_file.tell() == 0:
            csv_writer.writeheader()
        
        # Write the values of the dictionary as a row in the CSV file
        csv_writer.writerow(dictionary)


if __name__ == '__main__':

    if len(sys.argv) != 2:
        print("Usage: python script.py <csv_file_path> | Note: Use absoluty file path location.")
    else:
        file_input = sys.argv[1]

    file_name = '/home/a644542/code/input_files/remove_paths_from_epg.csv'

    # Remove the file if it exists
    if os.path.exists(file_name):
        os.remove(file_name)

    # Initialize the application log
    app_log = initialize_log("APP_LOG")

    # Load inputs from the CSV file
    inputs = csv_to_dict(file_input)
    app_log.info('CSV File loaded.')

    # Establish a session with the MSO server
    mso_session = MsoSession(ServerDictProps.get_values('mso_server_config.json'))
    app_log.info('MSO connection established.')
    
    ServerDictProps._ServerDictProps__values = None

    # Establish a session with the APIC server
    apic_session = ApicSession(ServerDictProps.get_values('apic_server_config.json'))
    app_log.info('APIC connection established.')

    # Load APIC node interfaces based on the input data
    fabrics : dict ({ tuple : ApicFabric }) = {}
    for site_node in set((node['nodeName']) for node in inputs): fabrics.update({site_node: ApicFabric(site_node, apic_session)})
    app_log.info('APIC fabrics loaded.')

    for input in inputs:
        vpc = fabrics[input['nodeName']].get_vpc_of_intf(input['intfName'])
        epgs = fabrics[input['nodeName']].get_epgs_of_intf(input['intfName'])

        for epg in epgs:
            
            csv_line = create_csv_object()
            csv_line['schema'], csv_line['applicationProfileName'], csv_line['epgName'] = epg.split('/')[1:]
            csv_line['schema'] = csv_line['schema'].replace('tn-', '')
            csv_line['siteName'] = input['siteName']
            csv_line['applicationProfileName'] = csv_line['applicationProfileName'].replace('ap-', '')
            csv_line['epgName'] = csv_line['epgName'].replace('epg-', '')
            csv_line['podName'] = fabrics[input['nodeName']].pod
            csv_line['intfName'] = vpc
            csv_line['intfType'] = 'vpc'

            # Retrieve the payload for the corresponding schema            
            payload = MsoSchema(csv_line['schema'], mso_session).payload
            # Site ID looks the same for all sites in Schema, using positon '0' to take the ID.
            site_id = payload['sites'][0]['siteId']

            # Find the Interface Path based in Interface Name
            interfaces = MsoInterfaces(input['siteName'], site_id, csv_line['intfType'], mso_session)
            interface_index = next((index for index, interface in enumerate(interfaces.interfaces['interfaces']) if interface['name'] == csv_line['intfName']), None)
            csv_line['nodeName'] = interfaces.interfaces['interfaces'][interface_index]['dn'].split('/')[2]

            # Find the template ID based on template name
            for template in payload['templates']:
                template_name = template['name']
                template_id = parser.parse('$.templates[?(@.name=="' + template_name + '")].templateID').find(payload)
                template_id = template_id[0].value

                # Create references for ANP and EPG based on the template name 
                anp_ref = '/schemas/' + payload['id'] + '/templates/' + template_name + '/anps/' + csv_line['applicationProfileName']
                epg_ref = anp_ref + '/epgs/' + csv_line['epgName']

                # Find the indices for site, ANP, and EPG in the payload
                site_index = next((index for index, site in enumerate(payload['sites']) if site['siteId'] == site_id and site['templateID'] == template_id), None)
                anp_index = next((index for index, anp in enumerate(payload['sites'][site_index]['anps']) if anp['anpRef'] == anp_ref), None)
                if anp_index is not None:
                    epg_index = next((index for index, epg in enumerate(payload['sites'][site_index]['anps'][anp_index]['epgs']) if epg['epgRef'] == epg_ref), None)
                    if epg_index is not None:
                        csv_line['templateName'] = template_name
                        append_to_csv(csv_line, file_name)