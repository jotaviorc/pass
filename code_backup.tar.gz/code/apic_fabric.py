from apic_session import ApicSession

import requests
requests.packages.urllib3.disable_warnings()

class ApicFabric:
    """
    Represents a fabric in the MSO (Multi-Site Orchestrator) system.

    This class provides methods to interact with fabrics in the MSO system. It allows retrieving the site ID, node DN, and fabric interface payload from the MSO API.

    Args:
        site_node (tuple): A tuple containing the site name and node name of the fabric.
        session (MsoSession): An instance of the MsoSession class representing the MSO server session.

    Raises:
        ConnectionError: If there is a connection error while establishing a connection with the MSO system.
        AttributeError: If there is an issue with the MSO site name or node name.

    Attributes:
        session (MsoSession): An instance of the MsoSession class representing the MSO server session.
        site (str): The name of the site associated with the fabric.
        site_id (str): The unique identifier of the site in the MSO system.
        node (str): The name of the fabric node within the site.
        node_dn (str): The distinguished name (DN) of the fabric node.
        type (str): The type of fabric, typically set to 'physical'.
        payload (dict): The payload containing fabric interface information retrieved from the MSO API.

    Methods:
        get_site_id(): Retrieves the unique identifier of the site from the MSO system.

            Returns:
                str: The ID of the site.

        get_node_dn(): Retrieves the distinguished name (DN) of the fabric node from the MSO API.

            Returns:
                str: The DN of the fabric node.

        get_if_payload(): Retrieves the fabric interface payload from the MSO API.

            Returns:
                dict: The payload of the fabric interfaces.

    Example:
        # Create an instance of MsoSession
        session = MsoSession(server_props)

        # Create an instance of MsoFabric
        site_node = ('MySite', 'MyNode')
        fabric = MsoFabric(site_node, session)

        # Retrieve the site ID
        site_id = fabric.get_site_id()

        # Retrieve the node DN
        node_dn = fabric.get_node_dn()

        # Retrieve the fabric interface payload
        interface_payload = fabric.get_if_payload()

        # Access fabric attributes or perform operations on the payload as needed.
    """
    
    def __init__ (self, site_node: str, session: ApicSession):
        self.session = session
        self.node = site_node
        self.node_dn, self.node_id = self.get_node_dn_id_by_name()
        self.pod = self.extract_pod()
        self.intf_payload = self.get_intf_payload()


    def get_node_dn_id_by_name(self):
        url = f"{self.session.base_url}/api/node/class/fabricNode.json"
        headers = {'Cookie': f'APIC-cookie={self.session.auth_token}'}
        try:
            response = requests.get(url, headers=headers, verify=self.session.certificate)
            if response.status_code == 200:
                nodes = response.json()['imdata']
                for node in nodes:
                    if self.node in node['fabricNode']['attributes']['name']:
                        return node['fabricNode']['attributes']['dn'], node['fabricNode']['attributes']['id']
                raise Exception("Failed to retrieve node ID from list!")
            else:
                raise Exception("Failed to retrieve node list!")
        except Exception as e:
            raise ConnectionError(f"Error retrieving node ID: {e}")


    def get_intf_payload(self):
        url = f"{self.session.base_url}/api/node/class/topology/{self.pod}/node-{self.node_id}/l1PhysIf.json"
        headers = {'Cookie': f'APIC-cookie={self.session.auth_token}'}
        try:
            response = requests.get(url, headers=headers, verify=self.session.certificate)
            if response.status_code == 200:
                return response.json()
            else:
                raise Exception("Failed to retrieve interfaces")
        except Exception as e:
            raise ConnectionError(f"Error retrieving interfaces: {e}")
        

    def extract_pod(self):
        parts = self.node_dn.split('/')
        for part in parts:
            if 'pod-' in part:
                return part
        raise Exception("Failed to retrieve Pod!")
    

    def get_vpc_of_intf(self, intf_name: str) -> str:
        url = f"{self.session.base_url}/api/node/mo/uni/infra/accportprof-{self.node}/hports-ifSel-{intf_name.replace('eth', '').replace('/', '_')}-typ-range.json?query-target=children"
        headers = {'Cookie': f'APIC-cookie={self.session.auth_token}'}
        try:
            response = requests.get(url, headers=headers, verify=self.session.certificate)
            if response.status_code == 200:
                data = response.json()
                for item in data['imdata']:
                    try:
                        if item['infraRsAccBaseGrp']['attributes']['tCl'] == 'infraAccBndlGrp':
                            return item['infraRsAccBaseGrp']['attributes']['tDn'].split('/')[-1].replace('accbundle-', '')
                    except KeyError:
                        None
                else:
                    raise Exception("Failed to retrieve VPC")
        except Exception as e:
            raise ConnectionError(f"Error retrieving VPC: {e}")
        

    def get_epgs_of_intf(self, intf_name: str) -> list:
        url = f"{self.session.base_url}/api/node/mo/topology/{self.pod}/node-{self.node_id}/sys/phys-[{intf_name}].json?rsp-subtree-include=full-deployment&target-node=all&target-path=l1EthIfToEPg"
        headers = {'Cookie': f'APIC-cookie={self.session.auth_token}'}
        try:
            response = requests.get(url, headers=headers, verify=self.session.certificate)
            if response.status_code == 200:
                data = response.json()
                epg_list = []
                for epg in data['imdata'][0]['l1PhysIf']['children'][0]['pconsCtrlrDeployCtx']['children']:
                    if epg['pconsResourceCtx']['attributes']['ctxClass'] == 'fvAEPg':
                        epg_list.append(epg['pconsResourceCtx']['attributes']['ctxDn'])
                return epg_list
            else:
                raise Exception("Failed to retrieve EPGs")
        except Exception as e:
            raise ConnectionError(f"Error retrieving EPGs: {e}")
